MAD — Abu Dhabi Directory & Relocation Companion

FILES
index.html: all HTML, CSS and JavaScript in one editable file.
README.txt: these instructions.
No build command, API key, installation or ChatGPT account is required.

PREVIEW AND UPLOAD
Extract the ZIP. Double-click index.html to preview it.
Upload index.html to your host's public_html, www or htdocs folder.
Alternatively, drag the extracted folder into https://app.netlify.com/drop.
Follow your host's instructions to connect your domain.
For updates, replace index.html with the latest file.

DIRECTORY
61 locations across 15 categories: schools, hospitals, dentists, gyms,
activities, museums/culture, hotels, restaurants, malls, groceries,
churches, mosques, other religious places, parks and beaches.
Search by name, category or area, or choose a category from the dropdown.
Show more places expands the displayed list. Listings include addresses,
directions, source links, published phone numbers and practical notes.
Nine official resource links cover visas, school discovery, healthcare,
transport, utilities, visitor mobile plans, currency and embassies.
The original relocation resource cards, community filters and locally
saved checklist are also included.

SOURCES AND MAINTENANCE
This is a curated directory checked on 2 October 2026, not a complete
live inventory of all businesses. Each listing links to an official
operator, mall, tourism or government source. Some sources publish only
a district or venue location rather than a street number. Check current
opening times, availability, entry rules and prices with each venue.
The Abrahamic Family House entries include the temporary closure notice
found on its official site when checked. Recheck it before updating.

EDITING
Open index.html in a text editor. CSS is in <style>; JavaScript is in
<script>. Find const placeDirectory to edit or add locations. Each record
has category, name, address, source, phone, checked, info and tags.
Supported categories are defined in directoryCategoryNames and
directoryKeywords. Add matching options to directoryCategory when
introducing another category. Re-upload after editing.

LIMITS
This is a static website, not an Apple or Google app-store package.
It has no shared database or user accounts. Checklist progress is saved
in the current browser and may be lost when browser data is cleared.
External resources and directions need internet access.

Latest interface update: directory is a compact bento panel, hidden until Search or Enter is submitted. Clear the search or use Close to hide it.
Checklist and resource boxes appear above the search-only directory.
Move section now includes a searchable Seepsc Consultancy relocation-support card linking to https://seepsc.com/.
